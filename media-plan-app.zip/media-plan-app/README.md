# Media Plan · Prüne Chile

App web de control de inversión y performance para Prüne Chile. Lee datos en vivo de BigQuery
(dataset `prune_cl`) y muestra pacing mensual, resultados por campaña y desglose por ad group,
con gráficos evolutivos multi-métrica.

## Arquitectura

- **Frontend**: `index.html` (una sola página, sin build). Usa Chart.js desde CDN.
- **Backend**: `api/query.js` — función serverless (Vercel) que corre queries de **solo lectura**
  a BigQuery usando una cuenta de servicio. El front nunca manda SQL: manda un `kind` + parámetros,
  y el backend arma la query (whitelisted + parametrizada).
- **Datos**: proyecto `gen-lang-client-0913063106`, vistas `prune_cl.master_campaign_results`
  (campañas, con GA4 y plataforma) y `prune_cl.master_ads_ad_results` (ad sets, sólo plataforma).
- **Moneda**: US$ (columnas normalizadas `cost`, `purchase_revenue`, `ads_purchase_revenue`).

## Deploy en Vercel (paso a paso)

### 1. Subir a GitHub
```bash
cd media-plan-app
git init
git add .
git commit -m "Media Plan Prune CL - v1"
git branch -M main
git remote add origin https://github.com/<tu-usuario>/media-plan-prune-cl.git
git push -u origin main
```

### 2. Crear la cuenta de servicio de BigQuery
En Google Cloud Console (proyecto `gen-lang-client-0913063106`):
1. IAM & Admin → **Service Accounts** → *Create service account* (ej. `media-plan-app`).
2. Asignarle los roles: **BigQuery Data Editor** y **BigQuery Job User**.
   - *Data Editor* (no sólo Viewer) porque la app además **escribe el plan mensual** en la tabla
     `prune_cl.media_plan_budgets` (presupuesto por campaña, compartido por el equipo).
   - Si preferís acotar: *Data Viewer* sobre el dataset `prune_cl` + *Data Editor* sólo sobre la
     tabla `media_plan_budgets` + *Job User* a nivel proyecto.
3. En la cuenta creada → *Keys* → *Add key* → *JSON*. Se descarga un archivo `.json`.
4. Guardá ese JSON: lo vas a pegar como variable de entorno (paso 4).

> La tabla `prune_cl.media_plan_budgets` ya está creada. Si hiciera falta recrearla:
> `CREATE TABLE prune_cl.media_plan_budgets (month STRING, platform STRING, campaign STRING, amount FLOAT64, updated_at TIMESTAMP);`

### 3. Importar el repo en Vercel
1. vercel.com → *Add New Project* → importá el repo de GitHub.
2. Framework Preset: **Other** (no hace falta build command).
3. Deploy.

### 4. Configurar variables de entorno (Vercel → Project → Settings → Environment Variables)
| Variable | Valor |
|---|---|
| `GCP_SA_KEY` | El **contenido completo** del JSON de la cuenta de servicio (en una sola línea). |
| `GCP_PROJECT` | *(opcional)* `gen-lang-client-0913063106` |
| `APP_KEY` | *(opcional, recomendado)* una clave de acceso. Si la definís, la app pide esta clave al entrar. |

Después de cargar las variables, **redeploy** (Deployments → … → Redeploy) para que tomen efecto.

### 5. Listo
Abrí la URL de Vercel. Si definiste `APP_KEY`, ingresá la clave. Vas a ver el pacing del mes y,
en la pestaña *Resultados por campaña*, el detalle con gráficos y ad groups.

## Desarrollo local (opcional)
```bash
npm install
npm i -g vercel
vercel dev            # levanta front + /api local
```
Cargá las variables en un `.env` local (ver `.env.example`) o con `vercel env pull`.

## Acceso / seguridad
- `APP_KEY` es una clave compartida simple (suficiente para uso interno). Para algo más robusto
  se puede sumar el *Password Protection* nativo de Vercel (plan Pro) o SSO/Google.
- La API es **solo lectura** (SELECT) y sólo expone las 7 consultas whitelisted de `api/query.js`.

## Notas de datos
- GA4 se mide a **nivel campaña** (no por ad set): en el desglose de ad groups sólo hay métricas
  de plataforma (Meta / Google Ads).
- Frecuencia no está en las vistas (no hay `reach`), por eso no se incluye.
- El **plan mensual por campaña se guarda en BigQuery** (`prune_cl.media_plan_budgets`), así que
  es **compartido por todo el equipo**: lo que carga una persona lo ven todas. Se guarda solo al
  editarlo (con un pequeño delay). Cada mes tiene su propio plan.
- El modo demo (toggle) sigue usando el navegador (localStorage), para no tocar datos reales.
